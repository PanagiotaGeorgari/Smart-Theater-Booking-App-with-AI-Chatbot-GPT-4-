package com.example.stagepass;

import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO {
    private static UserDAOImpl instance;
    private List<User> users;

    private UserDAOImpl() {
        users = new ArrayList<>();
    }
    public static synchronized UserDAOImpl getInstance() {
        if (instance == null) {
            instance = new UserDAOImpl();
        }
        return instance;
    }
    @Override
    public void addUser(User user) {
        users.add(user);
    }

    @Override
    public User getUserByemail(String email) {
        for (User user : users) {
            if (user.getEmail().equals(email)) {
                return user;
            }
        }
        return null;
    }
}
