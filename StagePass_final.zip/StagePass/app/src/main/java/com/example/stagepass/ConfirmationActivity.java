package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ConfirmationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirmation);


        //back button
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> finish());

        //tool bar
        //image button home (main ---> main)
        ImageButton homeBtn = findViewById(R.id.homeButton);//image button's name in main activity xml
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ConfirmationActivity.this, MainActivity.class);
            startActivity(intent);
        });
        //image button pen (main ---> complaints)
        ImageButton penBtn = findViewById(R.id.penButton);//image button's name in main activity xml
        penBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ConfirmationActivity.this, ComplainsActivity.class);
            startActivity(intent);
        });
        //image button phone (main ---> communicate)
        ImageButton phoneBtn = findViewById(R.id.phoneButton);//image button's name in main activity xml
        phoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ConfirmationActivity.this, CommunicateActivity.class);
            startActivity(intent);
        });
        //image button clock (main ---> history)
        ImageButton clockBtn = findViewById(R.id.clockButton);//image button's name in main activity xml
        clockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ConfirmationActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        //image button plus (main ---> book)
        ImageButton plusBtn = findViewById(R.id.plusButton);//image button's name in main activity xml
        plusBtn.setOnClickListener(v -> {

            Intent intent = new Intent(ConfirmationActivity.this, ChatBotActivity.class);
            startActivity(intent);

        });
        //submit
        Button submit = findViewById(R.id.submit);
        //image button's name in main activity xml
        submit.setOnClickListener(v -> {
            Toast.makeText(ConfirmationActivity.this, "Your booking has been successfully confirmed. A confirmation email will be sent to you shortly.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ConfirmationActivity.this, MainActivity.class);
            startActivity(intent);

        });
    }
}
