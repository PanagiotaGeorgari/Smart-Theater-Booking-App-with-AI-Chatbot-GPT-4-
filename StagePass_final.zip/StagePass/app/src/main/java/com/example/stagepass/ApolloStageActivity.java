package com.example.stagepass;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class ApolloStageActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.apollostage); //find xml file

        //---back button----
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> {
            finish(); // close activity
        });
    }
}
