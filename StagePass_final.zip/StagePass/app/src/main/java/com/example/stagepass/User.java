package com.example.stagepass;

import java.util.ArrayList;

public class User {
    String email;
    String password;

    ArrayList<Ticket> ticketperuser;
    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public User(String email, String password) {

        this.email = email;
        this.password = password;
        this.ticketperuser=new ArrayList<>();
    }
}
