package com.example.stagepass;

import java.util.List;

public interface UserDAO {
    void addUser(User user);
    User getUserByemail(String email);

}
