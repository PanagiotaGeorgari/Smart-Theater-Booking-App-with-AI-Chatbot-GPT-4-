package com.example.stagepass;

import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class BookActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book); //find xml

        //---back button----
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> {
            finish(); // close activity
        });
    }
}
