package com.example.stagepass;

import java.util.ArrayList;
import java.util.List;

public class CommunicateDAOImpl implements CommunicateDAO {
    private List<Communicate> communicates;

    public CommunicateDAOImpl() {
        communicates = new ArrayList<>();
    }

    @Override
    public void addcommunicate(Communicate com) {
        communicates.add(com);
        System.out.println("New communicate added: " + com.toString());
    }
}
