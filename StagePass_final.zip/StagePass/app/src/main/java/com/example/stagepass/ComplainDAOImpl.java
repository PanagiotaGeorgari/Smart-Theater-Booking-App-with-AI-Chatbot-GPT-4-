package com.example.stagepass;

import java.util.ArrayList;
import java.util.List;

public class ComplainDAOImpl implements ComplainDAO {
    private List<Complain> complaints;

    public ComplainDAOImpl() {
        complaints= new ArrayList<>();
    }

    @Override
    public void addcomplain(Complain com) {
        complaints.add(com);

    }
}
