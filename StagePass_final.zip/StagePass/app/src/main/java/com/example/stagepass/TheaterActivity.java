package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class TheaterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aboutus);

        //back button
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> {
            finish(); // close activity
        });

    }
}
