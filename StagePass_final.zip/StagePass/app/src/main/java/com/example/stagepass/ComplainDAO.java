package com.example.stagepass;

public interface ComplainDAO {
    void addcomplain(Complain com);

}
