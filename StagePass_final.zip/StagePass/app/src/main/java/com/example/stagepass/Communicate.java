package com.example.stagepass;

public class Communicate {
    String name;
    String surname;
    String phone;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }



    public Communicate(String surname, String phone, String name) {
        this.surname = surname;
        this.phone = phone;
        this.name = name;
    }

}
