package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CheckoutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkout);

        String play = getIntent().getStringExtra("play");
        String time = getIntent().getStringExtra("time");
        int tickets = getIntent().getIntExtra("tickets", 0);

        // Το description παραμένει σταθερό
        int price;
        TextView description = findViewById(R.id.description);
        TextView cost = findViewById(R.id.cost);
        if(play.equals("Electra")){
            cost.setText("$" + (tickets * 44));
            price = 44;
        }
        else {
            cost.setText("$" + (tickets * 30));
            price = 30;
        }


        // Γέμισμα της λίστας κρατήσεων
        ListView productList = findViewById(R.id.productList);

        String bookingText = play + " at " + time + " - " + tickets + " ticket(s)"+ " cost of each ticket            "+price+"$";
        String[] bookings = new String[]{ bookingText };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.item_booking,
                R.id.bookingItemText,
                //R.id.bookingItemPrice,
                bookings
        );

        productList.setAdapter(adapter);
        //back button
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> finish());

        //tool bar
        //image button home (main ---> main)
        ImageButton homeBtn = findViewById(R.id.homeButton);//image button's name in main activity xml
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, MainActivity.class);
            startActivity(intent);
        });
        //image button pen (main ---> complaints)
        ImageButton penBtn = findViewById(R.id.penButton);//image button's name in main activity xml
        penBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, ComplainsActivity.class);
            startActivity(intent);
        });
        //image button phone (main ---> communicate)
        ImageButton phoneBtn = findViewById(R.id.phoneButton);//image button's name in main activity xml
        phoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, CommunicateActivity.class);
            startActivity(intent);
        });
        //image button clock (main ---> history)
        ImageButton clockBtn = findViewById(R.id.clockButton);//image button's name in main activity xml
        clockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        //image button plus (main ---> book)
        ImageButton plusBtn = findViewById(R.id.plusButton);//image button's name in main activity xml
        plusBtn.setOnClickListener(v -> {
            //Intent intent = new Intent(MainActivity.this, BookActivity.class);
            //startActivity(intent);
            Intent intent = new Intent(CheckoutActivity.this, ChatBotActivity.class);
            startActivity(intent);

        });

        //place order
        Button submit = findViewById(R.id.submit);

        submit.setOnClickListener(v -> {
            Intent intent = new Intent(CheckoutActivity.this, ConfirmationActivity.class);
            startActivity(intent);
        });



    }


}
