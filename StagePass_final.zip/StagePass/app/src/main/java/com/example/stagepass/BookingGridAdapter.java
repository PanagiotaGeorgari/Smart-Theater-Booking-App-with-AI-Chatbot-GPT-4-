package com.example.stagepass;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class BookingGridAdapter extends BaseAdapter {
    private Context context;
    private List<BookingItem> bookings;

    @Override
    public int getCount() {
        return bookings.size();
    }

    @Override
    public Object getItem(int position) {
        return bookings.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BookingItem item = bookings.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.booking_grid_item, parent, false);
        }

        TextView itemText = convertView.findViewById(R.id.itemText);
        TextView descriptionText = convertView.findViewById(R.id.descriptionText);
        TextView statusText = convertView.findViewById(R.id.statusText);

        itemText.setText(item.getItemText());
        descriptionText.setText(item.getDescription());
        statusText.setText(item.getStatus());

        return convertView;
    }
}
