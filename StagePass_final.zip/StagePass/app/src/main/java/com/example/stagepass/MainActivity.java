package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); // Αυτό φορτώνει το main.xml


        //image button elektra (main ---> elektra info)
        ImageView elektraBtn = findViewById(R.id.elektra);//image button's name in main activity xml
        elektraBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ElektraActivity.class);
            startActivity(intent);
        });


        //image button theater (main ---> theater info)
        ImageView theaterBtn = findViewById(R.id.theater);//image button's name in main activity xml
        theaterBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TheaterActivity.class);
            startActivity(intent);
        });

        //image button dracula (main ---> dracula info)
        ImageView draculaBtn = findViewById(R.id.dracula);//image button's name in main activity xml
        draculaBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DraculaActivity.class);
            startActivity(intent);
        });

        //image button apollo stage(main ---> apollo stage info)
        ImageView apollostageBtn = findViewById(R.id.apollo);//image button's name in main activity xml
        apollostageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ApolloStageActivity.class);
            startActivity(intent);
        });

        //image button mainstage (main ---> main stage info)
        ImageView mainstageBtn = findViewById(R.id.themainstage);//image button's name in main activity xml
        mainstageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, TheMainStageActivity.class);
            startActivity(intent);
        });

        //tool bar
        //image button home (main ---> main)
        ImageButton homeBtn = findViewById(R.id.homeButton);//image button's name in main activity xml
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MainActivity.class);
            startActivity(intent);
        });
        //image button pen (main ---> complaints)
        ImageButton penBtn = findViewById(R.id.penButton);//image button's name in main activity xml
        penBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ComplainsActivity.class);
            startActivity(intent);
        });
        //image button phone (main ---> communicate)
        ImageButton phoneBtn = findViewById(R.id.phoneButton);//image button's name in main activity xml
        phoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CommunicateActivity.class);
            startActivity(intent);
        });
        //image button clock (main ---> history)
        ImageButton clockBtn = findViewById(R.id.clockButton);//image button's name in main activity xml
        clockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        //image button plus (main ---> book)
        ImageButton plusBtn = findViewById(R.id.plusButton);//image button's name in main activity xml
        plusBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ChatBotActivity.class);
            startActivity(intent);

        });


    }
}
