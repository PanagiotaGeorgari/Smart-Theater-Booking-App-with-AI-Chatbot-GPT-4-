package com.example.stagepass;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class HistoryListAdapter extends ArrayAdapter<BookingItem> {
    public HistoryListAdapter(Context context, List<BookingItem> items) {
        super(context, 0, items);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        BookingItem item = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_history, parent, false);
        }

        TextView playTitle = convertView.findViewById(R.id.playTitle);
        TextView playDescription = convertView.findViewById(R.id.playDescription);
        TextView quantity = convertView.findViewById(R.id.quantity);
        TextView status = convertView.findViewById(R.id.statusText);
        ImageView playImage = convertView.findViewById(R.id.playImage);

        playTitle.setText(item.play);
        playDescription.setText(item.play + " at " + item.time);
        quantity.setText("Quantity: " + item.tickets);
        status.setText("Confirmed");

        if (item.play.equalsIgnoreCase("Dracula")) {
            playImage.setImageResource(R.mipmap.dracula);
        } else if (item.play.equalsIgnoreCase("Electra")) {
            playImage.setImageResource(R.mipmap.elektra);
        }

        return convertView;
    }
}
