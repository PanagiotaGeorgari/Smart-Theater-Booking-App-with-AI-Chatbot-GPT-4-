package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SigninActivity extends AppCompatActivity {
    private UserDAO userDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin);
        userDAO = UserDAOImpl.getInstance();

        //login ---> main
        Button continueBtn = findViewById(R.id.continuebtn);
        EditText emailEditText = findViewById(R.id.email);
        EditText passwordEditText = findViewById(R.id.password);
        continueBtn.setOnClickListener(v -> {
            //take data from screen
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            //check if fields are empty
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(SigninActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            } else {

                //check if user exists
                User existingUser = userDAO.getUserByemail(email);
                if (existingUser != null) {
                    // user exists
                    Toast.makeText(SigninActivity.this, "Account already exists!", Toast.LENGTH_SHORT).show();
                } else {
                    // create new account because user does not exist
                    User newUser = new User(email, password);
                    userDAO.addUser(newUser);

                    Toast.makeText(SigninActivity.this, "Account created successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SigninActivity.this,LoginActivity.class);
                    startActivity(intent);
                }
            }
        });

        //---back button----
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> {
            finish(); // SigninActivity --> LoginActivity
        });

    }
}
