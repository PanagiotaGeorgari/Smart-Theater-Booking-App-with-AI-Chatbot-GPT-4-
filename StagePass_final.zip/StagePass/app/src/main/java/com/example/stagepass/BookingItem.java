package com.example.stagepass;

public class BookingItem {
    public String play;
    public String time;
    public int tickets;
   // public String timestamp;

    public BookingItem(String play, String time, int tickets) {
        this.play = play;
        this.time = time;
        this.tickets = tickets;
        //this.timestamp = timestamp;
    }

    public String getDescription() {
        return play + " at " + time;
    }

    public String getStatus() {
        return "Confirmed";
    }

    public String getItemText() {
        return tickets + " ticket(s)";
    }
}
