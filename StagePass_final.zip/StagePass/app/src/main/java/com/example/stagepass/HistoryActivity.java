package com.example.stagepass;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    //private ListView productList;
    private GridView productList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);

        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> finish());

        productList = findViewById(R.id.productList);

        fetchBookings();

        //tool bar
        //image button home (main ---> main)
        ImageButton homeBtn = findViewById(R.id.homeButton);//image button's name in main activity xml
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HistoryActivity.this, MainActivity.class);
            startActivity(intent);
        });
        //image button pen (main ---> complaints)
        ImageButton penBtn = findViewById(R.id.penButton);//image button's name in main activity xml
        penBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HistoryActivity.this, ComplainsActivity.class);
            startActivity(intent);
        });
        //image button phone (main ---> communicate)
        ImageButton phoneBtn = findViewById(R.id.phoneButton);//image button's name in main activity xml
        phoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HistoryActivity.this, CommunicateActivity.class);
            startActivity(intent);
        });
        //image button clock (main ---> history)
        ImageButton clockBtn = findViewById(R.id.clockButton);//image button's name in main activity xml
        clockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HistoryActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        //image button plus (main ---> book)
        ImageButton plusBtn = findViewById(R.id.plusButton);//image button's name in main activity xml
        plusBtn.setOnClickListener(v -> {
            //Intent intent = new Intent(MainActivity.this, BookActivity.class);
            //startActivity(intent);
            Intent intent = new Intent(HistoryActivity.this, ChatBotActivity.class);
            startActivity(intent);

        });


    }

    private void fetchBookings() {
        new AsyncTask<Void, Void, ArrayList<BookingItem>>() {
            @Override
            protected ArrayList<BookingItem> doInBackground(Void... voids) {
                ArrayList<BookingItem> items = new ArrayList<>();
                try {
                    URL url = new URL("http://10.0.2.2:5000/bookings"); // αλλαγή IP αν σε φυσική συσκευή
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    JSONArray json = new JSONArray(response.toString());
                    for (int i = 0; i < json.length(); i++) {
                        JSONObject obj = json.getJSONObject(i);
                        items.add(new BookingItem(
                                obj.getString("play"),
                                obj.getString("time"),
                                obj.getInt("tickets")
                        ));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return items;
            }

            @Override
            protected void onPostExecute(ArrayList<BookingItem> result) {
                HistoryListAdapter adapter = new HistoryListAdapter(HistoryActivity.this, result);
                productList.setAdapter(adapter);

            }
        }.execute();
    }
}
