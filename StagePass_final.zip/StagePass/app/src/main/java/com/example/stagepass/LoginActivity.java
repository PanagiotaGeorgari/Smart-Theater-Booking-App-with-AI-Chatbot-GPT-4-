package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private UserDAO userDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        //userDAO
        userDAO = UserDAOImpl.getInstance();


        //image button continue (login ---> main)
        Button continueBtn = findViewById(R.id.continuebtn);
        EditText emailEditText = findViewById(R.id.email);
        EditText passwordEditText = findViewById(R.id.password);

        //register button
        Button register= findViewById(R.id.createaccountbtn);
        register.setOnClickListener(v1 -> {
            Intent intent = new Intent(LoginActivity.this, SigninActivity.class);
            startActivity(intent);
        });

        continueBtn.setOnClickListener(v -> {
            //take data from screen
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // if fields are empty
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
            } else {
                //user already exists
                User existingUser = userDAO.getUserByemail(email);
                if (existingUser != null) {
                    // user exists -> verification with password
                    if (existingUser.getPassword().equals(password)) { //correct password
                        Toast.makeText(LoginActivity.this, "Login successfully!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {        //incorrect password
                        Toast.makeText(LoginActivity.this, "Wrong password!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // user does NOT exist --> press Create account
                    Toast.makeText(LoginActivity.this, "Account does NOT exist. Please click 'Create Account' to register.", Toast.LENGTH_SHORT).show();
                    //image button continue (login ---> signin)
                    Button signinBtn = findViewById(R.id.createaccountbtn);
                    signinBtn.setOnClickListener(v1 -> {
                        Intent intent = new Intent(LoginActivity.this, SigninActivity.class);
                        startActivity(intent);
                    });
                }
            }
        });






    }
}
