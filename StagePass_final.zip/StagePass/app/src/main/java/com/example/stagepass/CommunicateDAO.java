package com.example.stagepass;

public interface CommunicateDAO {
    void addcommunicate(Communicate com);


}
