package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CommunicateActivity extends AppCompatActivity {
    private CommunicateDAO communicateDAO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.communicate); // Αυτό φορτώνει το communicate.xml

        communicateDAO = new CommunicateDAOImpl();

        //---back button
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> {
            finish(); // close activity
        });

        //take data from screen
        EditText name = findViewById(R.id.name);
        EditText surname = findViewById(R.id.surname);
        EditText phone = findViewById(R.id.phone);
        Button submitBtn = findViewById(R.id.submit);
        submitBtn.setOnClickListener(v -> {
            String namedata = name.getText().toString().trim();
            String surnamedata = surname.getText().toString().trim();
            String phonedata = phone.getText().toString().trim();

            if (namedata.isEmpty() || surnamedata.isEmpty() || phonedata.isEmpty()) {
                Toast.makeText(this, "Please fill ALL the fields...", Toast.LENGTH_SHORT).show();

            } else {
                Communicate com = new Communicate(namedata, surnamedata, phonedata);
                communicateDAO.addcommunicate(com);
                Toast.makeText(this, "Your request for communication has been submitted SUCCESSFULLY.", Toast.LENGTH_SHORT).show();

            }


        });

        //tool bar
        //image button home (main ---> main)
        ImageButton homeBtn = findViewById(R.id.homeButton);//image button's name in main activity xml
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CommunicateActivity.this, MainActivity.class);
            startActivity(intent);
        });
        //image button pen (main ---> complaints)
        ImageButton penBtn = findViewById(R.id.penButton);//image button's name in main activity xml
        penBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CommunicateActivity.this, ComplainsActivity.class);
            startActivity(intent);
        });
        //image button phone (main ---> communicate)
        ImageButton phoneBtn = findViewById(R.id.phoneButton);//image button's name in main activity xml
        phoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CommunicateActivity.this, CommunicateActivity.class);
            startActivity(intent);
        });
        //image button clock (main ---> history)
        ImageButton clockBtn = findViewById(R.id.clockButton);//image button's name in main activity xml
        clockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CommunicateActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        //image button plus (main ---> book)
        ImageButton plusBtn = findViewById(R.id.plusButton);//image button's name in main activity xml
        plusBtn.setOnClickListener(v -> {
            Intent intent = new Intent(CommunicateActivity.this, BookActivity.class);
            startActivity(intent);
        });

    }
}
