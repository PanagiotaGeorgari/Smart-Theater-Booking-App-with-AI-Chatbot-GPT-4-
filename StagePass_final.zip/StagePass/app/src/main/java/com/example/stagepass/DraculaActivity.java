package com.example.stagepass;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class DraculaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dracula); // Αυτό φορτώνει το main.xml

        //back button
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> {
            finish(); // Κλείνει την τρέχουσα Activity και επιστρέφει στην προηγούμενη
        });
        //chatbot button
        Button booknowBtn = findViewById(R.id.bookNowButton);
        booknowBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DraculaActivity.this, ChatBotActivity.class); // αντικατάστησε το CurrentActivity με το όνομα της τρέχουσας activity
            startActivity(intent); // Κλείνει την τρέχουσα Activity και επιστρέφει στην προηγούμενη
        });
        //tool bar
        //image button home (main ---> main)
        ImageButton homeBtn = findViewById(R.id.homeButton);//image button's name in main activity xml
        homeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DraculaActivity.this, MainActivity.class);
            startActivity(intent);
        });
        //image button pen (main ---> complaints)
        ImageButton penBtn = findViewById(R.id.penButton);//image button's name in main activity xml
        penBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DraculaActivity.this, ComplainsActivity.class);
            startActivity(intent);
        });
        //image button phone (main ---> communicate)
        ImageButton phoneBtn = findViewById(R.id.phoneButton);//image button's name in main activity xml
        phoneBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DraculaActivity.this, CommunicateActivity.class);
            startActivity(intent);
        });
        //image button clock (main ---> history)
        ImageButton clockBtn = findViewById(R.id.clockButton);//image button's name in main activity xml
        clockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DraculaActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
        //image button plus (main ---> book)
        ImageButton plusBtn = findViewById(R.id.plusButton);//image button's name in main activity xml
        plusBtn.setOnClickListener(v -> {
            Intent intent = new Intent(DraculaActivity.this, ChatBotActivity.class);
            startActivity(intent);

        });
    }
}
