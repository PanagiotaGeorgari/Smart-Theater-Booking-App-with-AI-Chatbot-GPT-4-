package com.example.stagepass;

import android.content.Intent;
import android.os.Build;
import android.annotation.SuppressLint;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatBotActivity extends AppCompatActivity {

    private EditText userInput;
    private LinearLayout chatLayout;
    private ScrollView scrollView;
    private JSONArray history = new JSONArray();
    private BookingState currentBooking = new BookingState();
    private boolean bookingConfirmed = false;
    private String lastConfirmedBooking = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        userInput = findViewById(R.id.editMessage);
        Button sendBtn = findViewById(R.id.sendButton);
        chatLayout = findViewById(R.id.chatLayout);
        scrollView = findViewById(R.id.chatScroll);
        ImageButton backBtn = findViewById(R.id.backimg);
        backBtn.setOnClickListener(v -> finish());

        //send button
        sendBtn.setOnClickListener(v -> {
            String message = userInput.getText().toString().trim();
            if (!message.isEmpty()) {
                addMessage("Εσύ", message);
                userInput.setText("");
                if (message.toLowerCase().contains("cancel")) {
                    fetchBookingsWithButtons();
                } else {
                    sendToBot(message);
                }
            }
        });

        sendToBot("");
    }

    private void addMessage(String sender, String message) {
        int layoutId = sender.equals("Εσύ") ? R.layout.item_message_user : R.layout.item_message_bot;
        View bubble = getLayoutInflater().inflate(layoutId, null);
        TextView textMessage = bubble.findViewById(R.id.textMessage);
        textMessage.setText(message);
        chatLayout.addView(bubble);
        scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
    }

    private void sendToBot(String message) {
        try {
            if (!message.isEmpty()) {
                JSONObject userMessage = new JSONObject();
                userMessage.put("role", "user");
                userMessage.put("content", message);
                history.put(userMessage);
            }

            JSONObject payload = new JSONObject();
            payload.put("message", message);
            payload.put("history", history);

            new AsyncTask<JSONObject, Void, String>() {
                @Override
                protected String doInBackground(JSONObject... params) {
                    try {
                        URL url = new URL("http://10.0.2.2:5000/chat");
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Content-Type", "application/json");
                        conn.setDoOutput(true);

                        OutputStream os = conn.getOutputStream();
                        os.write(params[0].toString().getBytes("UTF-8"));
                        os.close();

                        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        JSONObject jsonResponse = new JSONObject(response.toString());
                        return jsonResponse.optString("response", "⚠️ No response");
                    } catch (Exception e) {
                        e.printStackTrace();
                        return "⚠️ Failed to connect to the bot.";
                    }
                }

                @Override
                protected void onPostExecute(String response) {
                    addMessage("Bot", response);

                    try {
                        JSONObject botMessage = new JSONObject();
                        botMessage.put("role", "assistant");
                        botMessage.put("content", response);
                        history.put(botMessage);
                    } catch (Exception ignored) {}


                    try {
                        //
                        if (response.toLowerCase().contains("dracula")) {
                            currentBooking.play = "Dracula";
                        } else if (response.toLowerCase().contains("electra")) {
                            currentBooking.play = "Electra";
                        }

                        // time
                        if (response.contains("5pm") || response.contains("17:00")) {
                            currentBooking.time = "5pm";
                        } else if (response.contains("9pm") || response.contains("21:00")) {
                            currentBooking.time = "9pm";
                        }
                        // tickets
                        Matcher m = Pattern.compile("(?i)(?:tickets?:|number of tickets:?|for)\\s*(\\d+)").matcher(response);
                        if (m.find()) {
                            currentBooking.tickets = Integer.parseInt(m.group(1));
                        }
                       /* // date
                        if (response.matches(".*\\d{4}-\\d{2}-\\d{2}.*")) {
                            Matcher dateMatcher = Pattern.compile("\\d{4}-\\d{2}-\\d{2}").matcher(response);
                            if (dateMatcher.find()) {
                                currentBooking.date = dateMatcher.group();
                            }
                        }*/
                        // ticket
                        java.util.regex.Matcher m1 = java.util.regex.Pattern.compile(
                                "(?i)(?:tickets?:|number of tickets:?|for)\\s*(\\d+)"
                        ).matcher(response);
                        if (m1.find()) {
                            currentBooking.tickets = Integer.parseInt(m1.group(1));
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    // confirm reservation
                    if (currentBooking.isComplete()) {
                        String key = currentBooking.play + "-" + currentBooking.time + "-" + currentBooking.tickets;
                        if (!key.equals(lastConfirmedBooking)) {
                            lastConfirmedBooking = key;
                            bookingConfirmed = true;
                            confirmBooking();
                        }
                    }

                    fetchBookingsAndCheckForNew();
                }

            }.execute(payload);

        } catch (Exception e) {
            e.printStackTrace();
            addMessage("Bot", "Error when sending message");
        }
    }

    @SuppressLint("StaticFieldLeak")
    private void confirmBooking() {
        try {
            // 🔒 Προληπτικός έλεγχος ημερομηνίας
            /*if (currentBooking.date != null) {
                LocalDate bookingDate = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    bookingDate = LocalDate.parse(currentBooking.date);
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (bookingDate.isBefore(LocalDate.now())) {
                        addMessage("Bot", "The date you provided is in the past. Please choose today or a future date.");
                        return;
                    }
                }
            }*/
            JSONObject body = new JSONObject();
            body.put("play", currentBooking.play);
            body.put("time", currentBooking.time);
            body.put("tickets", currentBooking.tickets);
            //body.put("date", LocalDate.now().toString());
           // body.put("date", currentBooking.date);

            new AsyncTask<JSONObject, Void, String>() {
                @Override
                protected String doInBackground(JSONObject... params) {
                    try {
                        URL url = new URL("http://10.0.2.2:5000/book");
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Content-Type", "application/json");
                        conn.setDoOutput(true);

                        OutputStream os = conn.getOutputStream();
                        os.write(params[0].toString().getBytes("UTF-8"));
                        os.close();

                        BufferedReader reader;

                        if (conn.getResponseCode() >= 400) {
                            reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                        } else {
                            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        }

                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();

                        return response.toString();
                    } catch (Exception e) {
                        e.printStackTrace();
                        return "{\"error\": \"Booking failed due to a connection error.\"}";
                    }
                }

                @Override
                protected void onPostExecute(String response) {
                    Log.d("BOOK_RESPONSE", "Raw JSON: " + response);  // 👈 ΝΕΟ!
                    try {

                        JSONObject json = new JSONObject(response);

                        if (json.has("error")) {
                            String errorMsg = json.getString("error");
                            addMessage("Bot", "Unfortunately, the booking could not be completed: " + errorMsg);
                            addMessage("Bot", "Can I help you with anything else? You can ask about bookings, cancellations, or performance information.");
                            bookingConfirmed = false;
                            lastConfirmedBooking = "";
                            return;
                        }

                        if (json.has("result")) {
                            String resultMsg = json.getString("result");
                            addMessage("Bot", resultMsg);

                            Button checkoutBtn = new Button(ChatBotActivity.this);
                            checkoutBtn.setText("Go to Checkout");
                            checkoutBtn.setBackgroundResource(R.drawable.shape2);
                            checkoutBtn.setTextColor(Color.WHITE);
                            checkoutBtn.setPadding(20, 10, 20, 10);

                            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT);
                            params.setMargins(20, 20, 20, 20);
                            checkoutBtn.setLayoutParams(params);

                            checkoutBtn.setOnClickListener(v -> {
                                Intent intent = new Intent(ChatBotActivity.this, CheckoutActivity.class);
                                intent.putExtra("play", currentBooking.play);
                                intent.putExtra("time", currentBooking.time);
                                intent.putExtra("tickets", currentBooking.tickets);
                                startActivity(intent);

                                currentBooking.clear();
                                bookingConfirmed = false;
                            });

                            chatLayout.addView(checkoutBtn);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        addMessage("Bot", "Failed to process server response.");
                        bookingConfirmed = false;
                        lastConfirmedBooking = "";
                    }
                }
            }.execute(body);
        } catch (Exception e) {
            e.printStackTrace();
            addMessage("Bot", " Σφάλμα κατά την αποστολή της κράτησης.");
        }
    }




    @SuppressLint("StaticFieldLeak")
    private void fetchBookingsWithButtons() {
        new AsyncTask<Void, Void, JSONArray>() {
            @Override
            protected JSONArray doInBackground(Void... voids) {
                try {
                    URL url = new URL("http://10.0.2.2:5000/bookings");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    return new JSONArray(response.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(JSONArray bookings) {
                if (bookings == null) {
                    addMessage("Bot", "Failed to fetch bookings.");
                    return;
                }

                for (int i = 0; i < bookings.length(); i++) {
                    try {
                        JSONObject booking = bookings.getJSONObject(i);
                        String play = booking.getString("play");
                        String time = booking.getString("time");
                        int tickets = booking.getInt("tickets");

                        Button cancelBtn = new Button(ChatBotActivity.this);
                        cancelBtn.setText("CANCEL: " + play.toUpperCase() + " - " + time + " - " + tickets + " ticket(s)");
                        cancelBtn.setAllCaps(false);
                        cancelBtn.setBackgroundResource(R.drawable.bg_ticket_button);
                        cancelBtn.setTextColor(Color.BLACK);
                        cancelBtn.setTypeface(null, Typeface.BOLD);
                        cancelBtn.setTextSize(12);

                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT);
                        params.setMargins(12, 12, 12, 0);
                        cancelBtn.setLayoutParams(params);

                        cancelBtn.setOnClickListener(v -> sendCancelRequest(play, time, tickets));
                        chatLayout.addView(cancelBtn);
                        //addMessage("Bot", "Can I help you with anything else? You can ask about bookings, cancellations, or performance information.\");\n");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                scrollView.post(() -> scrollView.fullScroll(View.FOCUS_DOWN));
            }
        }.execute();
    }

    @SuppressLint("StaticFieldLeak")
    private void sendCancelRequest(String play, String time, int tickets) {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL("http://10.0.2.2:5000/cancel");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json");
                    conn.setDoOutput(true);

                    JSONObject body = new JSONObject();
                    body.put("play", play);
                    body.put("time", time);
                    body.put("tickets", tickets);
                    //addMessage("Bot", "Can I help you with anything else? You can ask about bookings, cancellations, or performance information.\");\n");

                    OutputStream os = conn.getOutputStream();
                    os.write(body.toString().getBytes("UTF-8"));
                    os.close();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    reader.close();
                    //addMessage("Bot", "Can I help you with anything else? You can ask about bookings, cancellations, or performance information.\");\n");

                    return new JSONObject(response.toString()).optString("result", "Something went wrong");
                } catch (Exception e) {
                    e.printStackTrace();
                    return "Failed to cancel booking.";
                }
            }

            @Override
            protected void onPostExecute(String result) {
                addMessage("Bot", result);
                addMessage("Bot", "Can I help you with anything else? You can ask about bookings, cancellations, or performance information.");
            }
        }.execute();
    }

    @SuppressLint("StaticFieldLeak")
    private void fetchBookingsAndCheckForNew() {
        new AsyncTask<Void, Void, JSONArray>() {
            @Override
            protected JSONArray doInBackground(Void... voids) {
                try {
                    URL url = new URL("http://10.0.2.2:5000/bookings");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    return new JSONArray(response.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                    return null;
                }
            }

            @Override
            protected void onPostExecute(JSONArray bookings) {
                // optional use
            }
        }.execute();
    }

    public static class BookingState {
        public String play;
        public String time;
        public int tickets;
        //public String date;

        public boolean isComplete() {
            return play != null && time != null && tickets > 0 ;
        }

        public void clear() {
            play = null;
            time = null;
            tickets = 0;
        }
    }
}